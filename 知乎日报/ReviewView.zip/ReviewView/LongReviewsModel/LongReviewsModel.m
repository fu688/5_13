//
//  LongReviewsModel.m
//  知乎日报
//
//  Created by 付闯 on 2023/10/30.
//

#import "LongReviewsModel.h"
@implementation longReply_toModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation longConmentsModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
@implementation LongReviewsModel
+(BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
